
    <?= $this->extend('layout/template') ?>



    <?= $this->section('content') ?>
  
      <h1 class="display-3 text-center mt-5 ">Welcome to Arkademy</h1>

    <?= $this->endSection() ?>